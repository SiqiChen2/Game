package cs5004.marblesolitaire.model;
/**
 * This enum represents three status of each
 * position ont the board.
 */
public enum Status {
  OCCUPIED,EMPTY,INVALID
}
